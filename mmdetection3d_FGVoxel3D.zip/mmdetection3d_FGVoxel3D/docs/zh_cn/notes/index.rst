.. toctree::
   :maxdepth: 3

   benchmarks.md
   changelog_v1.0.x.md
   changelog.md
   compatibility.md
   faq.md
