.. toctree::
   :maxdepth: 1

   benchmarks.md
   changelog_v1.0.x.md
   changelog.md
   compatibility.md
   faq.md
   contribution_guides.md
